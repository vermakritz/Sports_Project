# Sports_Project

Packages:
body-parser
express
mysql2
nodemon


starting command 
- nodemon server.js